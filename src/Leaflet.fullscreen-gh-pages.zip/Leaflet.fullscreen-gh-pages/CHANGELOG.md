## 0.0.3

* Added IE11 native fullscreen support (#27)

## 0.0.2

* Set appropriate title when fullscreen (#17)
* Replace on('load') with whenReady (#19)

## 0.0.1

* Project restructuring
* New icons, including retina icons

## 0.0.0

* Initial release
